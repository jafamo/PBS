To build the Apache Lucene web app demo just run 
"ant war-demo" from the Apache Lucene Installation
directory (follow the master instructions in 
BUILD.txt).  If you have questions please post 
them to the Apache Lucene mailing lists.  To 
actually figure this out you really need to 
read the Lucene "Getting Started" guide provided
with the doc build ("ant docs").
